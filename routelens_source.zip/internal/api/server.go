package api

import (
	"io/fs"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/yuanweize/RouteLens/internal/auth"
	"github.com/yuanweize/RouteLens/internal/monitor"
	"github.com/yuanweize/RouteLens/pkg/storage"
)

type Server struct {
	router  *gin.Engine
	db      *storage.DB
	monitor *monitor.Service
	distFS  fs.FS
}

func NewServer(db *storage.DB, mon *monitor.Service, distFS fs.FS) *Server {
	r := gin.Default()
	s := &Server{
		router:  r,
		db:      db,
		monitor: mon,
		distFS:  distFS,
	}
	s.setupRoutes()
	return s
}

func (s *Server) Run(addr string) error {
	return s.router.Run(addr)
}

func (s *Server) setupRoutes() {
	// CORS (Dev mode mostly, but kept for safety if run separately)
	s.router.Use(func(c *gin.Context) {
		c.Writer.Header().Set("Access-Control-Allow-Origin", "*")
		c.Writer.Header().Set("Access-Control-Allow-Credentials", "true")
		c.Writer.Header().Set("Access-Control-Allow-Headers", "Content-Type, Content-Length, Accept-Encoding, X-CSRF-Token, Authorization, accept, origin, Cache-Control, X-Requested-With")
		c.Writer.Header().Set("Access-Control-Allow-Methods", "POST, OPTIONS, GET, PUT")

		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(204)
			return
		}
		c.Next()
	})

	// Static Assets (Phase 8)
	if s.distFS != nil {
		dist, _ := fs.Sub(s.distFS, "dist")

		// Serve static files from /assets
		// Vite builds put all assets in /assets, so we map /assets to dist/assets
		assetsFS, _ := fs.Sub(dist, "assets")
		s.router.StaticFS("/assets", http.FS(assetsFS))

		// SPA Fallback: All other non-API routes serve index.html
		s.router.NoRoute(func(c *gin.Context) {
			path := c.Request.URL.Path
			if strings.HasPrefix(path, "/api") {
				c.JSON(http.StatusNotFound, gin.H{"error": "API route not found"})
				return
			}

			// Load index.html from embedded FS
			indexHTML, err := fs.ReadFile(dist, "index.html")
			if err != nil {
				c.String(http.StatusInternalServerError, "Error loading index.html")
				return
			}

			// Serve index.html with 200 OK for all SPA routes
			c.Data(http.StatusOK, "text/html; charset=utf-8", indexHTML)
		})
	}

	// Public API
	s.router.POST("/login", s.handleLogin)

	// Protected API
	api := s.router.Group("/api/v1")
	api.Use(auth.AuthMiddleware())
	{
		api.GET("/status", s.handleStatus)
		api.GET("/history", s.handleHistory)
		api.POST("/probe", s.handleProbe)

		// Target CRUD
		api.GET("/targets", s.handleGetTargets)
		api.POST("/targets", s.handleSaveTarget)
		api.DELETE("/targets/:id", s.handleDeleteTarget)
	}
}

// -- Handlers --

func (s *Server) handleLogin(c *gin.Context) {
	var req struct {
		Password string `json:"password"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid payload"})
		return
	}

	if !auth.ValidatePassword(req.Password) {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "Invalid password"})
		return
	}

	token, err := auth.GenerateToken()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Token generation failed"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"token": token})
}

func (s *Server) handleStatus(c *gin.Context) {
	// TODO: Get real real-time status from Monitor Service cache
	// For now, return a mock
	c.JSON(http.StatusOK, gin.H{
		"targets": []gin.H{
			{
				"ip":           "8.8.8.8",
				"latency":      15.5,
				"loss":         0,
				"last_updated": time.Now(),
			},
		},
	})
}

func (s *Server) handleHistory(c *gin.Context) {
	s.handleStatus(c) // Use same mock for now
}

func (s *Server) handleProbe(c *gin.Context) {
	c.JSON(http.StatusAccepted, gin.H{"message": "Probe triggered"})
}

func (s *Server) handleGetTargets(c *gin.Context) {
	targets, err := s.db.GetTargets(false)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, targets)
}

func (s *Server) handleSaveTarget(c *gin.Context) {
	var t storage.Target
	if err := c.ShouldBindJSON(&t); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	if err := s.db.SaveTarget(&t); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, t)
}

func (s *Server) handleDeleteTarget(c *gin.Context) {
	idStr := c.Param("id")
	id, err := strconv.ParseUint(idStr, 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid ID"})
		return
	}
	if err := s.db.DeleteTarget(uint(id)); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "Target deleted"})
}
